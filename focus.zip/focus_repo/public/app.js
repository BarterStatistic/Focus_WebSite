/* ═══════════════════════════════════════════════════════
   FOCUS APP — Frontend Logic
   ═══════════════════════════════════════════════════════ */

const API = {
  async request(method, path, body) {
    const opts = {
      method,
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include'
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(path, opts);
    if (res.status === 401) { logout(); return null; }
    return res.json();
  },
  get: (path) => API.request('GET', path),
  post: (path, body) => API.request('POST', path, body),
  put: (path, body) => API.request('PUT', path, body),
  delete: (path) => API.request('DELETE', path)
};

// ─── State ────────────────────────────────────────────────
let state = {
  user: null,
  currentView: 'dashboard',
  currentProjectId: null,
  projects: [],
  teams: [],
  calendarEvents: [],
  googleConnected: false,
  selectedColor: '#00ffb4',
  confirmCallback: null
};

// ─── Toast ────────────────────────────────────────────────
function toast(msg, type = 'success') {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.innerHTML = `<span>${icons[type]}</span> ${msg}`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ─── Modal helpers ────────────────────────────────────────
function openModal(id) {
  document.getElementById(id).classList.add('active');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('active');
}
function confirm(message, callback) {
  document.getElementById('confirm-message').textContent = message;
  state.confirmCallback = callback;
  openModal('modal-confirm');
}

// ─── Navigation ───────────────────────────────────────────
function navigate(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const viewEl = document.getElementById(`view-${view}`);
  if (viewEl) viewEl.classList.add('active');

  const navEl = document.querySelector(`[data-view="${view}"]`);
  if (navEl) navEl.classList.add('active');

  state.currentView = view;

  // Cargar datos de la vista
  if (view === 'dashboard') loadDashboard();
  else if (view === 'projects') loadProjects();
  else if (view === 'teams') loadTeams();
  else if (view === 'calendar') loadCalendar();
  else if (view === 'settings') loadSettings();
}

// ─── Auth ─────────────────────────────────────────────────
async function checkAuth() {
  const data = await API.get('/api/auth/me');
  if (data && data.id) {
    state.user = data;
    state.googleConnected = data.googleConnected;
    showApp();
  } else {
    showLogin();
  }
}

function showLogin() {
  document.getElementById('login-page').classList.add('active');
  document.getElementById('app').classList.remove('active');
}

function showApp() {
  document.getElementById('login-page').classList.remove('active');
  document.getElementById('app').classList.add('active');
  updateUserUI();
  navigate('dashboard');
}

function updateUserUI() {
  if (!state.user) return;
  const name = state.user.username;
  const initials = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
  document.getElementById('user-avatar').textContent = initials;
  document.getElementById('user-name').textContent = name;
  document.getElementById('settings-username').textContent = name;
  // Greeting
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Buenos días' : hour < 18 ? 'Buenas tardes' : 'Buenas noches';
  document.getElementById('dashboard-greeting').textContent = `${greet}, ${name.split(' ')[0]} 👋`;
}

function logout() {
  API.post('/api/auth/logout');
  state.user = null;
  showLogin();
}

// ─── Login form ───────────────────────────────────────────
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  const errEl = document.getElementById('login-error');
  errEl.style.display = 'none';

  const data = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
    credentials: 'include'
  }).then(r => r.json());

  if (data.success) {
    state.user = data.user;
    state.googleConnected = false;
    showApp();
  } else {
    errEl.style.display = 'block';
    errEl.textContent = data.error || 'Credenciales incorrectas';
  }
});

// ═══════════════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════════════

async function loadDashboard() {
  const [projects, teams] = await Promise.all([
    API.get('/api/projects'),
    API.get('/api/teams')
  ]);

  state.projects = projects || [];
  state.teams = teams || [];

  const active = state.projects.filter(p => p.status === 'active');
  const totalPlans = state.projects.reduce((s, p) => s + (p.plan_count || 0), 0);
  const completedPlans = state.projects.reduce((s, p) => s + (p.completed_plans || 0), 0);

  document.getElementById('stat-projects').textContent = active.length;
  document.getElementById('stat-plans').textContent = totalPlans;
  document.getElementById('stat-completed').textContent = completedPlans;
  document.getElementById('stat-teams').textContent = state.teams.length;

  // Recent projects
  const dashProjects = document.getElementById('dash-projects-list');
  const recent = state.projects.slice(0, 4);
  if (recent.length === 0) {
    dashProjects.innerHTML = `<div class="empty-state" style="padding:24px;">
      <div class="icon">📁</div>
      <p>Aún no tienes proyectos.</p>
    </div>`;
  } else {
    dashProjects.innerHTML = recent.map(p => `
      <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);cursor:pointer;" onclick="openProject(${p.id})">
        <div style="width:10px;height:10px;border-radius:50%;background:${p.color};flex-shrink:0;"></div>
        <div style="flex:1;">
          <div style="font-size:13px;font-weight:500;">${escHtml(p.name)}</div>
          <div style="font-size:11px;color:var(--text-muted);">${p.plan_count || 0} planes · ${p.completed_plans || 0} completados</div>
        </div>
        <span class="badge badge-${p.status}">${p.status === 'active' ? 'Activo' : 'Archivado'}</span>
      </div>
    `).join('');
  }

  // Calendar events on dashboard
  const dashEvents = document.getElementById('dash-events-list');
  if (state.googleConnected) {
    const calData = await API.get('/api/calendar/events');
    if (calData && calData.events) {
      const upcoming = calData.events.slice(0, 3);
      if (upcoming.length === 0) {
        dashEvents.innerHTML = `<div style="color:var(--text-muted);font-size:13px;text-align:center;padding:20px;">No hay eventos próximos.</div>`;
      } else {
        dashEvents.innerHTML = upcoming.map(ev => renderEventItem(ev)).join('');
      }
    }
  } else {
    dashEvents.innerHTML = `<div style="text-align:center;padding:20px;">
      <div style="font-size:2rem;margin-bottom:8px;">📅</div>
      <p style="font-size:13px;color:var(--text-secondary);margin-bottom:12px;">Conecta Google Calendar para ver tus eventos aquí.</p>
      <button class="btn btn-secondary btn-sm" onclick="navigate('settings')">Conectar ahora</button>
    </div>`;
  }
}

// ═══════════════════════════════════════════════════════
// PROJECTS
// ═══════════════════════════════════════════════════════

async function loadProjects() {
  const projects = await API.get('/api/projects');
  state.projects = projects || [];
  renderProjects();
}

function renderProjects() {
  const grid = document.getElementById('projects-grid');
  if (state.projects.length === 0) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
      <div class="icon">📁</div>
      <h3>Aún no tienes proyectos</h3>
      <p>Crea tu primer proyecto para empezar a organizar tu trabajo.</p>
    </div>`;
    return;
  }
  grid.innerHTML = state.projects.map(p => {
    const progress = p.plan_count > 0 ? Math.round((p.completed_plans / p.plan_count) * 100) : 0;
    return `
    <div class="project-card fade-in" style="--project-color:${p.color}" onclick="openProject(${p.id})">
      <div class="project-card-header">
        <div>
          <div class="project-name">${escHtml(p.name)}</div>
          <span class="badge badge-${p.status}">${p.status === 'active' ? 'Activo' : 'Archivado'}</span>
        </div>
        <div class="project-actions" onclick="event.stopPropagation()">
          <button class="btn btn-ghost btn-icon btn-sm" onclick="editProject(${p.id})" title="Editar">✏️</button>
          <button class="btn btn-ghost btn-icon btn-sm" onclick="deleteProject(${p.id}, '${escHtml(p.name)}')" title="Eliminar">🗑</button>
        </div>
      </div>
      <div class="project-description">${escHtml(p.description || 'Sin descripción')}</div>
      <div class="progress-bar" style="margin-bottom:10px">
        <div class="progress-fill" style="width:${progress}%"></div>
      </div>
      <div class="project-footer">
        <span class="project-meta">${p.plan_count || 0} planes · ${p.completed_plans || 0} completados</span>
        <span class="project-meta">${progress}%</span>
      </div>
    </div>`;
  }).join('');
}

async function openProject(id) {
  state.currentProjectId = id;
  const project = state.projects.find(p => p.id === id);
  if (!project) return;

  // Update detail header
  document.getElementById('detail-project-name').textContent = project.name;
  document.getElementById('detail-project-desc').textContent = project.description || '';
  document.getElementById('detail-project-status').textContent = project.status === 'active' ? 'Activo' : 'Archivado';
  document.getElementById('detail-project-status').className = `badge badge-${project.status}`;
  document.getElementById('detail-color-dot').style.background = project.color;

  navigate('project-detail');
  loadPlans();
}

// ─── Project modal ────────────────────────────────────────
function openNewProjectModal() {
  document.getElementById('modal-project-title').textContent = 'Nuevo Proyecto';
  document.getElementById('project-id').value = '';
  document.getElementById('project-name').value = '';
  document.getElementById('project-description').value = '';
  document.getElementById('project-status').value = 'active';
  selectProjectColor('#00ffb4');
  openModal('modal-project');
}

function editProject(id) {
  const p = state.projects.find(p => p.id === id);
  if (!p) return;
  document.getElementById('modal-project-title').textContent = 'Editar Proyecto';
  document.getElementById('project-id').value = p.id;
  document.getElementById('project-name').value = p.name;
  document.getElementById('project-description').value = p.description || '';
  document.getElementById('project-status').value = p.status;
  selectProjectColor(p.color);
  openModal('modal-project');
}

function selectProjectColor(color) {
  state.selectedColor = color;
  document.getElementById('project-color').value = color;
  document.querySelectorAll('.color-dot').forEach(dot => {
    dot.classList.toggle('selected', dot.dataset.color === color);
  });
}

document.getElementById('form-project').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('project-id').value;
  const body = {
    name: document.getElementById('project-name').value.trim(),
    description: document.getElementById('project-description').value.trim(),
    status: document.getElementById('project-status').value,
    color: document.getElementById('project-color').value
  };

  let result;
  if (id) {
    result = await API.put(`/api/projects/${id}`, body);
  } else {
    result = await API.post('/api/projects', body);
  }

  if (result && !result.error) {
    closeModal('modal-project');
    toast(id ? 'Proyecto actualizado' : 'Proyecto creado', 'success');
    await loadProjects();
    if (id && state.currentProjectId == id) openProject(parseInt(id));
  } else {
    toast(result?.error || 'Error al guardar', 'error');
  }
});

async function deleteProject(id, name) {
  confirm(`¿Eliminar el proyecto "${name}"? También se eliminarán todos sus planes.`, async () => {
    const result = await API.delete(`/api/projects/${id}`);
    if (result?.success) {
      toast('Proyecto eliminado', 'success');
      await loadProjects();
      navigate('projects');
    } else {
      toast('Error al eliminar', 'error');
    }
  });
}

// ─── Color picker event ───────────────────────────────────
document.getElementById('project-color-picker').addEventListener('click', (e) => {
  const dot = e.target.closest('.color-dot');
  if (dot) selectProjectColor(dot.dataset.color);
});

// ═══════════════════════════════════════════════════════
// PLANS
// ═══════════════════════════════════════════════════════

async function loadPlans() {
  if (!state.currentProjectId) return;
  const plans = await API.get(`/api/projects/${state.currentProjectId}/plans`);
  renderPlans(plans || []);
}

function renderPlans(plans) {
  const container = document.getElementById('plans-list');
  if (plans.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <div class="icon">📋</div>
      <h3>Sin planes aún</h3>
      <p>Crea un plan para organizar las acciones de este proyecto.</p>
    </div>`;
    return;
  }

  const priorityLabel = { high: 'Alta', medium: 'Media', low: 'Baja' };
  const statusLabel = { pending: 'Pendiente', in_progress: 'En progreso', completed: 'Completado' };

  container.innerHTML = plans.map(plan => {
    const taskProgress = plan.task_count > 0
      ? Math.round((plan.completed_tasks / plan.task_count) * 100) : 0;

    const tasksHtml = (plan.tasks || []).map(t => `
      <div class="task-item" data-task-id="${t.id}">
        <div class="task-checkbox ${t.completed ? 'checked' : ''}" onclick="toggleTask(${t.id}, ${!t.completed}, this)">
          ${t.completed ? '✓' : ''}
        </div>
        <span class="task-title ${t.completed ? 'done' : ''}" id="task-title-${t.id}">${escHtml(t.title)}</span>
        <span class="task-delete" onclick="deleteTask(${t.id}, ${plan.id})">✕</span>
      </div>
    `).join('');

    return `
    <div class="plan-card fade-in" id="plan-${plan.id}">
      <div class="plan-header">
        <div class="plan-title">${escHtml(plan.title)}</div>
        <div style="display:flex;gap:4px;">
          <button class="btn btn-ghost btn-icon btn-sm" onclick="editPlan(${plan.id})" title="Editar">✏️</button>
          <button class="btn btn-ghost btn-icon btn-sm" onclick="deletePlan(${plan.id}, '${escHtml(plan.title)}')" title="Eliminar">🗑</button>
        </div>
      </div>
      <div class="plan-meta">
        <span class="badge badge-${plan.status}">${statusLabel[plan.status] || plan.status}</span>
        <span class="badge badge-${plan.priority}">${priorityLabel[plan.priority] || plan.priority}</span>
        ${plan.due_date ? `<span class="plan-due">📅 ${formatDate(plan.due_date)}</span>` : ''}
      </div>
      ${plan.description ? `<div class="plan-description">${escHtml(plan.description)}</div>` : ''}
      ${plan.task_count > 0 ? `
      <div class="progress-bar" style="margin-bottom:8px">
        <div class="progress-fill" style="width:${taskProgress}%"></div>
      </div>
      <div style="font-size:11px;color:var(--text-muted);margin-bottom:8px">${plan.completed_tasks}/${plan.task_count} tareas completadas</div>
      ` : ''}
      <div class="tasks-section">
        <div class="task-items" id="tasks-${plan.id}">${tasksHtml}</div>
        <div class="add-task-input">
          <input type="text" id="new-task-${plan.id}" placeholder="+ Agregar tarea..." onkeydown="if(event.key==='Enter'){addTask(${plan.id});event.preventDefault();}" />
          <button class="btn btn-secondary btn-sm" onclick="addTask(${plan.id})">+</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

// ─── Plan modal ───────────────────────────────────────────
function openNewPlanModal() {
  document.getElementById('modal-plan-title').textContent = 'Nuevo Plan';
  document.getElementById('plan-id').value = '';
  document.getElementById('plan-title').value = '';
  document.getElementById('plan-description').value = '';
  document.getElementById('plan-priority').value = 'medium';
  document.getElementById('plan-status').value = 'pending';
  document.getElementById('plan-due-date').value = '';
  openModal('modal-plan');
}

async function editPlan(id) {
  const plan = await API.get(`/api/projects/${state.currentProjectId}/plans`)
    .then(plans => plans?.find(p => p.id === id));
  if (!plan) return;

  document.getElementById('modal-plan-title').textContent = 'Editar Plan';
  document.getElementById('plan-id').value = plan.id;
  document.getElementById('plan-title').value = plan.title;
  document.getElementById('plan-description').value = plan.description || '';
  document.getElementById('plan-priority').value = plan.priority;
  document.getElementById('plan-status').value = plan.status;
  document.getElementById('plan-due-date').value = plan.due_date || '';
  openModal('modal-plan');
}

document.getElementById('form-plan').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('plan-id').value;
  const body = {
    title: document.getElementById('plan-title').value.trim(),
    description: document.getElementById('plan-description').value.trim(),
    priority: document.getElementById('plan-priority').value,
    status: document.getElementById('plan-status').value,
    due_date: document.getElementById('plan-due-date').value || null
  };

  let result;
  if (id) {
    result = await API.put(`/api/plans/${id}`, body);
  } else {
    result = await API.post(`/api/projects/${state.currentProjectId}/plans`, body);
  }

  if (result && !result.error) {
    closeModal('modal-plan');
    toast(id ? 'Plan actualizado' : 'Plan creado', 'success');
    loadPlans();
  } else {
    toast(result?.error || 'Error al guardar', 'error');
  }
});

async function deletePlan(id, title) {
  confirm(`¿Eliminar el plan "${title}"?`, async () => {
    const result = await API.delete(`/api/plans/${id}`);
    if (result?.success) {
      toast('Plan eliminado', 'success');
      loadPlans();
    } else {
      toast('Error al eliminar', 'error');
    }
  });
}

// ─── Tasks ────────────────────────────────────────────────
async function addTask(planId) {
  const input = document.getElementById(`new-task-${planId}`);
  const title = input.value.trim();
  if (!title) return;

  const result = await API.post(`/api/plans/${planId}/tasks`, { title });
  if (result && !result.error) {
    input.value = '';
    loadPlans();
  } else {
    toast('Error al crear tarea', 'error');
  }
}

async function toggleTask(taskId, completed, el) {
  const result = await API.put(`/api/tasks/${taskId}`, { completed });
  if (result && !result.error) {
    el.classList.toggle('checked', completed);
    el.textContent = completed ? '✓' : '';
    const titleEl = document.getElementById(`task-title-${taskId}`);
    if (titleEl) titleEl.classList.toggle('done', completed);
    // Reload to update progress
    setTimeout(() => loadPlans(), 300);
  }
}

async function deleteTask(taskId, planId) {
  const result = await API.delete(`/api/tasks/${taskId}`);
  if (result?.success) loadPlans();
}

// ═══════════════════════════════════════════════════════
// TEAMS
// ═══════════════════════════════════════════════════════

async function loadTeams() {
  const [teams, projects] = await Promise.all([
    API.get('/api/teams'),
    API.get('/api/projects')
  ]);
  state.teams = teams || [];
  state.projects = projects || [];
  renderTeams();
}

function renderTeams() {
  const grid = document.getElementById('teams-grid');
  if (state.teams.length === 0) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
      <div class="icon">👥</div>
      <h3>Aún no tienes equipos</h3>
      <p>Crea tu primer equipo para asignar proyectos y dar seguimiento.</p>
    </div>`;
    return;
  }

  grid.innerHTML = state.teams.map(team => {
    const membersHtml = (team.members || []).map(m => `
      <div class="member-chip">
        <span>👤 ${escHtml(m.name)}${m.role ? ` <span class="member-role">· ${escHtml(m.role)}</span>` : ''}</span>
        <span class="remove" onclick="removeMember(${team.id}, ${m.id})">✕</span>
      </div>
    `).join('') || '<span style="font-size:12px;color:var(--text-muted)">Sin miembros</span>';

    const projectChips = (team.projects || []).map(p => `
      <div class="project-chip">
        <span>📁 ${escHtml(p.name)}</span>
        <span class="remove" onclick="removeTeamProject(${team.id}, ${p.id})">✕</span>
      </div>
    `).join('') || '<span style="font-size:12px;color:var(--text-muted)">Sin proyectos</span>';

    // Projects not yet assigned
    const assignedIds = (team.projects || []).map(p => p.id);
    const available = state.projects.filter(p => !assignedIds.includes(p.id) && p.status === 'active');
    const projectOptions = available.map(p => `<option value="${p.id}">${escHtml(p.name)}</option>`).join('');

    return `
    <div class="team-card fade-in">
      <div class="team-header">
        <div>
          <div class="team-name">👥 ${escHtml(team.name)}</div>
          ${team.description ? `<div class="team-desc">${escHtml(team.description)}</div>` : ''}
        </div>
        <div style="display:flex;gap:4px;">
          <button class="btn btn-ghost btn-icon btn-sm" onclick="editTeam(${team.id})" title="Editar">✏️</button>
          <button class="btn btn-ghost btn-icon btn-sm" onclick="deleteTeam(${team.id}, '${escHtml(team.name)}')" title="Eliminar">🗑</button>
        </div>
      </div>

      <div class="team-section-label">Miembros</div>
      <div id="members-${team.id}">${membersHtml}</div>
      <div class="team-add-row" style="margin-top:8px;">
        <input type="text" id="new-member-name-${team.id}" placeholder="Nombre..." style="flex:1;" />
        <input type="text" id="new-member-role-${team.id}" placeholder="Rol..." style="flex:1;" />
        <button class="btn btn-secondary btn-sm" onclick="addMember(${team.id})">+ Agregar</button>
      </div>

      <div class="team-section-label" style="margin-top:16px;">Proyectos asignados</div>
      <div id="team-projects-${team.id}">${projectChips}</div>
      ${available.length > 0 ? `
      <div class="team-add-row" style="margin-top:8px;">
        <select id="assign-project-${team.id}" style="flex:1;">
          <option value="">Seleccionar proyecto...</option>
          ${projectOptions}
        </select>
        <button class="btn btn-secondary btn-sm" onclick="assignProject(${team.id})">Asignar</button>
      </div>` : `<div style="font-size:11px;color:var(--text-muted);margin-top:6px;">Todos los proyectos activos ya están asignados.</div>`}
    </div>`;
  }).join('');
}

// ─── Team modal ───────────────────────────────────────────
function openNewTeamModal() {
  document.getElementById('modal-team-title').textContent = 'Nuevo Equipo';
  document.getElementById('team-id').value = '';
  document.getElementById('team-name').value = '';
  document.getElementById('team-description').value = '';
  openModal('modal-team');
}

function editTeam(id) {
  const team = state.teams.find(t => t.id === id);
  if (!team) return;
  document.getElementById('modal-team-title').textContent = 'Editar Equipo';
  document.getElementById('team-id').value = team.id;
  document.getElementById('team-name').value = team.name;
  document.getElementById('team-description').value = team.description || '';
  openModal('modal-team');
}

document.getElementById('form-team').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('team-id').value;
  const body = {
    name: document.getElementById('team-name').value.trim(),
    description: document.getElementById('team-description').value.trim()
  };

  let result;
  if (id) {
    result = await API.put(`/api/teams/${id}`, body);
  } else {
    result = await API.post('/api/teams', body);
  }

  if (result && !result.error) {
    closeModal('modal-team');
    toast(id ? 'Equipo actualizado' : 'Equipo creado', 'success');
    loadTeams();
  } else {
    toast(result?.error || 'Error al guardar', 'error');
  }
});

async function deleteTeam(id, name) {
  confirm(`¿Eliminar el equipo "${name}"?`, async () => {
    const result = await API.delete(`/api/teams/${id}`);
    if (result?.success) {
      toast('Equipo eliminado', 'success');
      loadTeams();
    } else {
      toast('Error al eliminar', 'error');
    }
  });
}

async function addMember(teamId) {
  const name = document.getElementById(`new-member-name-${teamId}`).value.trim();
  const role = document.getElementById(`new-member-role-${teamId}`).value.trim();
  if (!name) return toast('El nombre es requerido', 'error');

  const result = await API.post(`/api/teams/${teamId}/members`, { name, role });
  if (result && !result.error) {
    toast('Miembro agregado', 'success');
    loadTeams();
  } else {
    toast('Error al agregar miembro', 'error');
  }
}

async function removeMember(teamId, memberId) {
  const result = await API.delete(`/api/teams/${teamId}/members/${memberId}`);
  if (result?.success) loadTeams();
}

async function assignProject(teamId) {
  const sel = document.getElementById(`assign-project-${teamId}`);
  const projectId = sel.value;
  if (!projectId) return;

  const result = await API.post(`/api/teams/${teamId}/projects`, { project_id: projectId });
  if (result?.success) {
    toast('Proyecto asignado', 'success');
    loadTeams();
  } else {
    toast('Error al asignar proyecto', 'error');
  }
}

async function removeTeamProject(teamId, projectId) {
  const result = await API.delete(`/api/teams/${teamId}/projects/${projectId}`);
  if (result?.success) loadTeams();
}

// ═══════════════════════════════════════════════════════
// CALENDAR
// ═══════════════════════════════════════════════════════

async function loadCalendar() {
  const content = document.getElementById('calendar-content');
  content.innerHTML = `<div style="text-align:center;padding:40px;color:var(--text-muted);">Cargando eventos...</div>`;

  const data = await API.get('/api/calendar/events');

  if (!data || !data.connected) {
    content.innerHTML = `
      <div class="calendar-connect-banner">
        <div style="font-size:3rem;margin-bottom:12px;">📅</div>
        <h3>Conecta tu Google Calendar</h3>
        <p>Sincroniza tus eventos para verlos directamente en Focus y gestionarlos junto con tus proyectos.</p>
        <button class="btn btn-primary" onclick="connectGoogle()">Conectar Google Calendar</button>
      </div>`;
    return;
  }

  state.googleConnected = true;
  const events = data.events || [];

  if (events.length === 0) {
    content.innerHTML = `<div class="empty-state">
      <div class="icon">📅</div>
      <h3>No hay eventos próximos</h3>
      <p>Tu calendario está vacío para los próximos 30 días.</p>
    </div>`;
    return;
  }

  content.innerHTML = `<div class="events-list">${events.map(ev => renderEventItem(ev)).join('')}</div>`;
}

function renderEventItem(ev) {
  const start = ev.start?.dateTime || ev.start?.date;
  const d = start ? new Date(start) : null;
  const day = d ? d.getDate() : '--';
  const month = d ? d.toLocaleString('es', { month: 'short' }) : '--';
  const time = ev.start?.dateTime ? d.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' }) : 'Todo el día';

  return `
    <div class="event-item">
      <div class="event-date">
        <div class="event-day">${day}</div>
        <div class="event-month">${month}</div>
      </div>
      <div class="event-info">
        <div class="event-title">${escHtml(ev.summary || 'Sin título')}</div>
        <div class="event-time">⏰ ${time}</div>
        ${ev.location ? `<div class="event-location">📍 ${escHtml(ev.location)}</div>` : ''}
      </div>
    </div>`;
}

async function connectGoogle() {
  const data = await API.get('/api/calendar/auth-url');
  if (data?.url) {
    window.location.href = data.url;
  } else {
    toast('Google Calendar no está configurado en el servidor. Revisa el archivo .env', 'error');
  }
}

// ═══════════════════════════════════════════════════════
// SETTINGS
// ═══════════════════════════════════════════════════════

async function loadSettings() {
  const user = await API.get('/api/auth/me');
  if (user) {
    state.googleConnected = user.googleConnected;
    document.getElementById('settings-username').textContent = user.username;
    updateGoogleButton();
  }

  // Check URL params for Google OAuth result
  const hash = window.location.hash;
  if (hash.includes('google=connected')) {
    toast('Google Calendar conectado correctamente', 'success');
    state.googleConnected = true;
    updateGoogleButton();
    window.location.hash = '#settings';
  } else if (hash.includes('google=error')) {
    toast('Error al conectar Google Calendar. Intenta de nuevo.', 'error');
    window.location.hash = '#settings';
  }
}

function updateGoogleButton() {
  const el = document.getElementById('google-calendar-action');
  if (state.googleConnected) {
    el.innerHTML = `<div style="display:flex;align-items:center;gap:10px;">
      <div class="google-connected">✅ Conectado</div>
      <button class="btn btn-secondary btn-sm" onclick="disconnectGoogle()">Desconectar</button>
    </div>`;
  } else {
    el.innerHTML = `<button class="btn btn-primary btn-sm" onclick="connectGoogle()">Conectar</button>`;
  }
}

async function disconnectGoogle() {
  confirm('¿Desconectar Google Calendar?', async () => {
    const result = await API.delete('/api/calendar/disconnect');
    if (result?.success) {
      state.googleConnected = false;
      updateGoogleButton();
      toast('Google Calendar desconectado', 'info');
    }
  });
}

// ═══════════════════════════════════════════════════════
// GLOBAL EVENT LISTENERS
// ═══════════════════════════════════════════════════════

// Navigation clicks
document.querySelectorAll('[data-view]').forEach(el => {
  el.addEventListener('click', () => navigate(el.dataset.view));
});

// Quick nav from dashboard cards
document.querySelectorAll('[data-view-go]').forEach(el => {
  el.addEventListener('click', (e) => {
    e.stopPropagation();
    navigate(el.dataset.viewGo);
  });
});

// Close modals
document.querySelectorAll('[data-close-modal]').forEach(el => {
  el.addEventListener('click', () => closeModal(el.dataset.closeModal));
});
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) overlay.classList.remove('active');
  });
});

// Confirm modal
document.getElementById('confirm-action-btn').addEventListener('click', () => {
  closeModal('modal-confirm');
  if (state.confirmCallback) state.confirmCallback();
});

// New project button
document.getElementById('btn-new-project').addEventListener('click', openNewProjectModal);

// Edit/Delete project from detail view
document.getElementById('btn-edit-project').addEventListener('click', () => {
  if (state.currentProjectId) editProject(state.currentProjectId);
});
document.getElementById('btn-delete-project').addEventListener('click', () => {
  if (state.currentProjectId) {
    const p = state.projects.find(p => p.id === state.currentProjectId);
    if (p) deleteProject(p.id, p.name);
  }
});

// New plan button
document.getElementById('btn-new-plan').addEventListener('click', openNewPlanModal);

// Back to projects
document.getElementById('back-to-projects').addEventListener('click', () => navigate('projects'));

// New team button
document.getElementById('btn-new-team').addEventListener('click', openNewTeamModal);

// Refresh calendar
document.getElementById('btn-refresh-calendar').addEventListener('click', loadCalendar);

// Logout
document.getElementById('logout-btn').addEventListener('click', logout);
document.getElementById('settings-logout').addEventListener('click', logout);

// ─── Utilities ────────────────────────────────────────────
function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('es', { day: 'numeric', month: 'short', year: 'numeric' });
}

// ─── Handle Google OAuth callback ─────────────────────────
function handleHashChange() {
  const hash = window.location.hash;
  if (hash.includes('#settings')) {
    navigate('settings');
  }
}
window.addEventListener('hashchange', handleHashChange);

// ─── Init ─────────────────────────────────────────────────
checkAuth();
handleHashChange();
